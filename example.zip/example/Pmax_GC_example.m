%Example test case for Pmax_GC.m
%Data from San Francisco Bay, CA, USA

load('con_freq.mat'); %load inputs 
load('con_names.mat');
load('con_tran.mat');
load('tran_length.mat');

[Pmax, Qmax, m, a]=Pmax_GC(con_names, con_freq, con_tran, tran_length); %call function

fprintf('Pmax = %.1f [MW] \n', Pmax) %print outputs
fprintf('Qmax = %.0f [m^3/s]\n', Qmax)
fprintf('Amplitude = %.2f [m]\n', a)
fprintf('Multipying Factor = %.2f [-]\n', m)
