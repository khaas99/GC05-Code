%Creates a transect of interpolated tidal constituents using data from the 
%tidal database (enhanced with data from 

%**************************************************************************
%                      1. USER-ENTERED INFORMATION
%**************************************************************************

%-------------------- 1.1 File Information --------------------------------

%File names for constituents input data
con_file='data_sfb.mat'; %constituents file for location

%Do you have netCDF data (simplifies transect selection)? 1 for yes. 
netCDFs_exist=0; 

%File names for netCDF input data
if netCDFs_exist
    ncfile_start='.\GC_Locations\ma_s\out_nc\ma_s_402x402_his_0001.nc'; %start = 30 days prior to last day (3)
    ncfile_end='.\GC_Locations\ma_s\out_nc\ma_s_402x402_his_0032.nc'; %last day of series (32)
end
    
%-------------- 1.2 Plot Grid to Select Transect Points -------------------
%Plot grid to facilitate transect selection

%    -------------------------------------------------------------------
%    |         ***PLOTTING  GRID WITH NETCDFS IS PREFERRED***          | 
%    |  IF NETCDFS ARE NOT AVAILABLE, PLOT WITH CONSTITUENT DATA. ONLY |
%    |  CENTERPOINTS OF GRID CELLS ARE PLOTTED WITH THIS METHOD, SO    |
%    |  SO ESTIMATE THE LOCATIONS OF GRID CELL CORNERS & SELECT THESE  |
%    |  AS TRANSECT ENDPOINTS.                                         |
%    -------------------------------------------------------------------

if netCDFs_exist
    %Plot grid from netCDFs for reference when selecting transect endpoints
    lat_rho=ncread(ncfile_start, 'lat_rho'); %latitude
    lon_rho=ncread(ncfile_start, 'lon_rho'); %longitude
    h=ncread(ncfile_start, 'h'); %water depth
    mask_rho=ncread(ncfile_start, 'mask_rho'); %1 if water
    h(~mask_rho)=NaN; %if not water point, don't plot
    h(h<=2)=NaN; %don't plot shallow/intertidal
    pcolorjw(lon_rho, lat_rho, h), shading flat, axis equal, 
    cb=colorbar; hold on;
    
else
    %Plot grid with constituents file only (use only if netCDFs not available)
    load(con_file);
    lon_grid=cell2mat(data(:,2));
    lat_grid=cell2mat(data(:,3));
    depth_grid=cell2mat(data(:,4));
    scatter(lon_grid, lat_grid, 10, depth_grid, 'filled'); hold on;
end


%----------------------- 1.3 Select Transects -----------------------------

%Define endpoints of transects at corners of land grid cells
%Suggested precision: at least four decimal places 

%Transect 1: Crosses Resource Assessment Center Point
lat1(1)=37.78917;
lon1(1)=-122.499365;
lat2(1)=37.82438;
lon2(1)=-122.523285;


num_lines=length(lat1);

%Plot transects overtop grid (check if transects are okay)
for a=1:num_lines
   plot([lon1(a), lon2(a)], [lat1(a), lat2(a)], 'y', 'linewidth', 2); 
end


%**************************************************************************
%            2.  INTERPOLATE CONSTITUENT DATA TO TRANSECT
%**************************************************************************

%--------------------- 2.1 Load constituent data --------------------------

%IF CONSTITUENTS DATA IS IN CELL ARRAY (as pulled from findrecords.m)
load(con_file); %Variable name: "data"
dataLon=cell2mat(data(:,2)); %longitude
dataLat=cell2mat(data(:,3)); %latitude
depth=cell2mat(data(:,4)); %water depth
amp=cell2mat(data(:, 5:14)); %constituent amplitudes
vMaj=cell2mat(data(:, 25:34)); %constituent current velocities, major axis
inc=cell2mat(data(:, 45:54)); %constituent inclination angles
ph=cell2mat(data(:, 55:64)); %constituent phases


%--------------------------2.2 Remove bad data-----------------------------

%999 signals bad data
amp(amp(:,:)<=-999)=NaN;
depth(depth<=-999)=NaN;
vMaj(vMaj(:,:)<=-999)=NaN;
inc(inc(:,:)<=-999)=NaN;
ph(ph(:,:)<=-999)=NaN;

%Remove P1 and K2 constituents (keep 8 for t_predic)
amp(:,[3,8])=[];
vMaj(:, [3,8])=[];
inc(:, [3,8])=[];
ph(:, [3,8])=[];

%Count number of constituents (8 if using database)
num_cons=size(amp, 2);

%----------------2.3 Determine discrete transect segments------------------
spacing=20;

%Get transect length
tran_length = pos2dist(lat1,lon1,lat2,lon2,1)*1000; %use method 1 for plane
num_points=floor(tran_length/spacing);

%Get coordinates of endpoints of discrete transect lengths
tranX_end=linspace(lon1,lon2,num_points+1); %x-coordinates (lon) 
tranY_end=linspace(lat1,lat2,num_points+1); %y-coordinates (lat)

%Get coordiantes of midpoints of discrete transect lengths 
for L=1:length(tranX_end)-1
    tranX_mid(L)=mean([tranX_end(L), tranX_end(L+1)]);
    tranY_mid(L)=mean([tranY_end(L), tranY_end(L+1)]); 
end

%-------------- 2.4 Interpolate data onto segment midpoints----------------

%Interpolate depth 
tran_depth=griddata(dataLon,dataLat,depth,tranX_mid,tranY_mid, 'linear')';

%Loop through all constituents, interpolating characteristics of each
for con=1:size(amp,2)
    tran_amp(:,con)=griddata(dataLon,dataLat,amp(:,con),tranX_mid,tranY_mid, 'linear');
    tran_vMaj(:,con)=griddata(dataLon,dataLat,vMaj(:,con),tranX_mid,tranY_mid, 'linear');
    tran_inc(:,con)=griddata(dataLon, dataLat, inc(:,con),tranX_mid,tranY_mid, 'linear');
    tran_ph(:,con)=griddata(dataLon, dataLat, ph(:,con),tranX_mid,tranY_mid, 'linear');
end

%**************************************************************************
%            2.  Save data as inputs for Pmax_GC.m
%**************************************************************************

%constituents interpolated to transect
con_tran=[tranY_mid(:), tranX_mid(:), tran_depth(:), tran_amp(:,:), tran_vMaj(:,:), tran_ph(:,:), tran_inc(:,:)];
save('con_tran.mat', 'con_tran');

%constituent names
con_names=['Q1';'O1';'K1';'N2';'M2';'S2';'M4';'M6']; 
save('con_names.mat', 'con_names');

%constituent frequencies
con_freq=[1/26.8684; 1/25.81; 1/23.9345; 1/12.6583; 1/12.4206; 1/12; 1/6.2103; 1/4.1402]; 
save('con_freq.mat', 'con_freq');

%length of transect
save('tran_length.mat', 'tran_length');
